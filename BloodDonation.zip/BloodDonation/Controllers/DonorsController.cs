using BloodDonation.Data;
using BloodDonation.Models;
using BloodDonation.ViewModels;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize]
    public class DonorsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DonorsController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index(DonorFilterViewModel filter)
        {
            var q = _db.Donors.Include(d => d.BloodType).AsQueryable();
            if (!string.IsNullOrEmpty(filter.SearchName))
                q = q.Where(d => d.FullName.Contains(filter.SearchName) || d.Email.Contains(filter.SearchName));
            if (filter.BloodTypeId.HasValue)
                q = q.Where(d => d.BloodTypeId == filter.BloodTypeId);
            if (filter.IsEligible.HasValue)
                q = q.Where(d => d.IsEligible == filter.IsEligible);
            if (!string.IsNullOrEmpty(filter.Gender))
                q = q.Where(d => d.Gender == filter.Gender);

            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
            ViewBag.Filter = filter;
            return View(await q.OrderBy(d => d.FullName).ToListAsync());
        }

        public async Task<IActionResult> Details(int id)
        {
            var donor = await _db.Donors.Include(d => d.BloodType).Include(d => d.Donations)
                .FirstOrDefaultAsync(d => d.DonorId == id);
            if (donor == null) return NotFound();
            return View(donor);
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Create()
        {
            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
            return View();
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Donor donor)
        {
            ModelState.Remove("BloodType");
            ModelState.Remove("Donations");
            if (!ModelState.IsValid)
            {
                ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
                return View(donor);
            }
            _db.Donors.Add(donor);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Donor registered successfully!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Edit(int id)
        {
            var donor = await _db.Donors.FindAsync(id);
            if (donor == null) return NotFound();
            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name", donor.BloodTypeId);
            return View(donor);
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Donor donor)
        {
            if (id != donor.DonorId) return BadRequest();
            ModelState.Remove("BloodType");
            ModelState.Remove("Donations");
            if (!ModelState.IsValid)
            {
                ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name", donor.BloodTypeId);
                return View(donor);
            }
            _db.Update(donor);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Donor updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var donor = await _db.Donors.Include(d => d.BloodType).FirstOrDefaultAsync(d => d.DonorId == id);
            if (donor == null) return NotFound();
            return View(donor);
        }

        [HttpPost, ActionName("Delete"), Authorize(Roles = "Admin"), ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var donor = await _db.Donors.FindAsync(id);
            if (donor != null) { _db.Donors.Remove(donor); await _db.SaveChangesAsync(); }
            TempData["Success"] = "Donor deleted.";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> ExportExcel(DonorFilterViewModel filter)
        {
            var q = _db.Donors.Include(d => d.BloodType).AsQueryable();
            if (!string.IsNullOrEmpty(filter.SearchName)) q = q.Where(d => d.FullName.Contains(filter.SearchName));
            if (filter.BloodTypeId.HasValue) q = q.Where(d => d.BloodTypeId == filter.BloodTypeId);
            var donors = await q.OrderBy(d => d.FullName).ToListAsync();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Donors");
            ws.Cell(1, 1).Value = "Full Name"; ws.Cell(1, 2).Value = "Email"; ws.Cell(1, 3).Value = "Phone";
            ws.Cell(1, 4).Value = "Blood Type"; ws.Cell(1, 5).Value = "Gender"; ws.Cell(1, 6).Value = "Eligible";
            ws.Row(1).Style.Font.Bold = true;
            int row = 2;
            foreach (var d in donors)
            {
                ws.Cell(row, 1).Value = d.FullName; ws.Cell(row, 2).Value = d.Email; ws.Cell(row, 3).Value = d.Phone;
                ws.Cell(row, 4).Value = d.BloodType.Name; ws.Cell(row, 5).Value = d.Gender; ws.Cell(row, 6).Value = d.IsEligible ? "Yes" : "No";
                row++;
            }
            ws.Columns().AdjustToContents();
            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return File(ms.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Donors.xlsx");
        }
    }
}
