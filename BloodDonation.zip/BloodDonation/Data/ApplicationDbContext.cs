using BloodDonation.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<BloodType> BloodTypes { get; set; }
        public DbSet<Donor> Donors { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Hospital> Hospitals { get; set; }
        public DbSet<BloodRequest> BloodRequests { get; set; }
        public DbSet<BloodInventory> BloodInventories { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Seed Blood Types
            builder.Entity<BloodType>().HasData(
                new BloodType { BloodTypeId = 1, Name = "A+" },
                new BloodType { BloodTypeId = 2, Name = "A-" },
                new BloodType { BloodTypeId = 3, Name = "B+" },
                new BloodType { BloodTypeId = 4, Name = "B-" },
                new BloodType { BloodTypeId = 5, Name = "AB+" },
                new BloodType { BloodTypeId = 6, Name = "AB-" },
                new BloodType { BloodTypeId = 7, Name = "O+" },
                new BloodType { BloodTypeId = 8, Name = "O-" }
            );

            // Seed Inventory
            builder.Entity<BloodInventory>().HasData(
                new BloodInventory { InventoryId = 1, BloodTypeId = 1, AvailableQuantityMl = 4500, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 2, BloodTypeId = 2, AvailableQuantityMl = 2250, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 3, BloodTypeId = 3, AvailableQuantityMl = 3600, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 4, BloodTypeId = 4, AvailableQuantityMl = 900, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 5, BloodTypeId = 5, AvailableQuantityMl = 1800, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 6, BloodTypeId = 6, AvailableQuantityMl = 450, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 7, BloodTypeId = 7, AvailableQuantityMl = 5400, ExpiryDate = DateTime.Now.AddDays(42) },
                new BloodInventory { InventoryId = 8, BloodTypeId = 8, AvailableQuantityMl = 1350, ExpiryDate = DateTime.Now.AddDays(42) }
            );

            // Seed sample hospitals
            builder.Entity<Hospital>().HasData(
                new Hospital { HospitalId = 1, Name = "King Faisal Hospital", Address = "Kigali, Rwanda", Phone = "+250788000001", Email = "info@kfh.rw", ContactPerson = "Dr. Jean" },
                new Hospital { HospitalId = 2, Name = "CHUK University Hospital", Address = "Kigali, Rwanda", Phone = "+250788000002", Email = "info@chuk.rw", ContactPerson = "Dr. Marie" }
            );

            // Seed sample donors
            builder.Entity<Donor>().HasData(
                new Donor { DonorId = 1, FullName = "Alice Mutoni", Email = "alice@example.com", Phone = "+250780001001", DateOfBirth = new DateTime(1990, 5, 15), Gender = "Female", Address = "Kigali, Rwanda", BloodTypeId = 1, RegisteredAt = DateTime.Now.AddMonths(-6) },
                new Donor { DonorId = 2, FullName = "Bob Kamanzi", Email = "bob@example.com", Phone = "+250780001002", DateOfBirth = new DateTime(1985, 8, 22), Gender = "Male", Address = "Kigali, Rwanda", BloodTypeId = 3, RegisteredAt = DateTime.Now.AddMonths(-3) },
                new Donor { DonorId = 3, FullName = "Clara Uwase", Email = "clara@example.com", Phone = "+250780001003", DateOfBirth = new DateTime(1995, 2, 10), Gender = "Female", Address = "Kigali, Rwanda", BloodTypeId = 7, RegisteredAt = DateTime.Now.AddMonths(-1) }
            );

            // Seed sample donations
            builder.Entity<Donation>().HasData(
                new Donation { DonationId = 1, DonorId = 1, DonationDate = DateTime.Now.AddMonths(-5), QuantityMl = 450, Status = "Approved", Notes = "Routine donation", CreatedAt = DateTime.Now.AddMonths(-5) },
                new Donation { DonationId = 2, DonorId = 2, DonationDate = DateTime.Now.AddMonths(-2), QuantityMl = 450, Status = "Approved", Notes = "Routine donation", CreatedAt = DateTime.Now.AddMonths(-2) },
                new Donation { DonationId = 3, DonorId = 3, DonationDate = DateTime.Now.AddDays(-10), QuantityMl = 450, Status = "Pending", CreatedAt = DateTime.Now.AddDays(-10) }
            );

            // Seed blood requests
            builder.Entity<BloodRequest>().HasData(
                new BloodRequest { BloodRequestId = 1, HospitalId = 1, BloodTypeId = 1, QuantityMl = 900, Urgency = "Urgent", Status = "Pending", PatientName = "John Doe", RequestDate = DateTime.Now.AddDays(-2) },
                new BloodRequest { BloodRequestId = 2, HospitalId = 2, BloodTypeId = 7, QuantityMl = 450, Urgency = "Normal", Status = "Approved", PatientName = "Jane Smith", RequestDate = DateTime.Now.AddDays(-5) }
            );
        }
    }
}
