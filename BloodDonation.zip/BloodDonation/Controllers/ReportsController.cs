using BloodDonation.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize(Roles = "Admin,Manager")]
    public class ReportsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public ReportsController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index()
        {
            var inventoryData = await _db.BloodInventories.Include(i => i.BloodType)
                .Select(i => new { type = i.BloodType.Name, qty = i.AvailableQuantityMl }).ToListAsync();
            var donationsByMonth = await _db.Donations
                .Where(d => d.DonationDate >= DateTime.Now.AddMonths(-6))
                .GroupBy(d => new { d.DonationDate.Year, d.DonationDate.Month })
                .Select(g => new { month = g.Key.Month + "/" + g.Key.Year, count = g.Count() })
                .OrderBy(x => x.month).ToListAsync();
            var requestsByStatus = await _db.BloodRequests
                .GroupBy(r => r.Status)
                .Select(g => new { status = g.Key, count = g.Count() }).ToListAsync();

            ViewBag.InventoryLabels = System.Text.Json.JsonSerializer.Serialize(inventoryData.Select(x => x.type));
            ViewBag.InventoryData = System.Text.Json.JsonSerializer.Serialize(inventoryData.Select(x => x.qty));
            ViewBag.DonationLabels = System.Text.Json.JsonSerializer.Serialize(donationsByMonth.Select(x => x.month));
            ViewBag.DonationData = System.Text.Json.JsonSerializer.Serialize(donationsByMonth.Select(x => x.count));
            ViewBag.RequestLabels = System.Text.Json.JsonSerializer.Serialize(requestsByStatus.Select(x => x.status));
            ViewBag.RequestData = System.Text.Json.JsonSerializer.Serialize(requestsByStatus.Select(x => x.count));
            return View();
        }

        public async Task<IActionResult> ExportInventoryExcel()
        {
            var data = await _db.BloodInventories.Include(i => i.BloodType).ToListAsync();
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Inventory");
            ws.Cell(1, 1).Value = "Blood Type"; ws.Cell(1, 2).Value = "Available (ml)"; ws.Cell(1, 3).Value = "Status"; ws.Cell(1, 4).Value = "Last Updated";
            ws.Row(1).Style.Font.Bold = true;
            int row = 2;
            foreach (var i in data)
            {
                ws.Cell(row, 1).Value = i.BloodType.Name; ws.Cell(row, 2).Value = (double)i.AvailableQuantityMl;
                ws.Cell(row, 3).Value = i.AvailableQuantityMl > 3000 ? "High" : i.AvailableQuantityMl > 1000 ? "Medium" : "Low";
                ws.Cell(row, 4).Value = i.LastUpdated.ToString("yyyy-MM-dd HH:mm");
                row++;
            }
            ws.Columns().AdjustToContents();
            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return File(ms.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "BloodInventory.xlsx");
        }
    }
}
