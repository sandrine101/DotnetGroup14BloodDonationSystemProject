using BloodDonation.Data;
using BloodDonation.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize]
    public class HospitalsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public HospitalsController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index(string? search)
        {
            var q = _db.Hospitals.AsQueryable();
            if (!string.IsNullOrEmpty(search)) q = q.Where(h => h.Name.Contains(search) || h.Address.Contains(search));
            ViewBag.Search = search;
            return View(await q.OrderBy(h => h.Name).ToListAsync());
        }

        [Authorize(Roles = "Admin,Manager")]
        public IActionResult Create() => View();

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Hospital hospital)
        {
            ModelState.Remove("BloodRequests");
            if (!ModelState.IsValid) return View(hospital);
            _db.Hospitals.Add(hospital);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Hospital added!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Edit(int id)
        {
            var h = await _db.Hospitals.FindAsync(id);
            if (h == null) return NotFound();
            return View(h);
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Hospital hospital)
        {
            if (id != hospital.HospitalId) return BadRequest();
            ModelState.Remove("BloodRequests");
            if (!ModelState.IsValid) return View(hospital);
            _db.Update(hospital);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Hospital updated!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var h = await _db.Hospitals.FindAsync(id);
            if (h == null) return NotFound();
            return View(h);
        }

        [HttpPost, ActionName("Delete"), Authorize(Roles = "Admin"), ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var h = await _db.Hospitals.FindAsync(id);
            if (h != null) { _db.Hospitals.Remove(h); await _db.SaveChangesAsync(); }
            TempData["Success"] = "Hospital deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
