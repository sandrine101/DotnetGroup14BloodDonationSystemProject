# Blood Donation Management System
## ASP.NET Core 8 MVC — SQLite — Identity Auth

### Quick Start
```bash
# 1. Install .NET 8 SDK from https://dotnet.microsoft.com/download
# 2. Open terminal in this folder
dotnet restore
dotnet run
# 3. Open browser: https://localhost:5001
```

### Demo Credentials
| Role    | Email                         | Password    |
|---------|-------------------------------|-------------|
| Admin   | admin@blooddonation.com       | Admin123!   |
| Manager | manager@blooddonation.com     | Manager123! |
| Client  | client@blooddonation.com      | Client123!  |

### Features
- Landing Page
- Authentication & Authorization (Admin / Manager / Client roles)
- Donors CRUD + Excel Export
- Donations CRUD + Approve/Reject + Excel Export
- Blood Requests CRUD + Approve/Reject + Excel Export
- Hospitals CRUD
- Blood Inventory (auto-updated on donation approval)
- Reports with Charts (Bar, Line, Doughnut)
- Role-based page/button/URL access control
- Toast notifications on all actions
- 5 Linked Tables: Donors, Donations, BloodRequests, Hospitals, BloodInventory

### Database
SQLite — auto-created on first run. Seeded with blood types, sample donors, hospitals, and users.
