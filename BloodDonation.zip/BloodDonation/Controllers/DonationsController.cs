using BloodDonation.Data;
using BloodDonation.Models;
using BloodDonation.ViewModels;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize]
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DonationsController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index(DonationFilterViewModel filter)
        {
            var q = _db.Donations.Include(d => d.Donor).ThenInclude(d => d.BloodType).AsQueryable();
            if (filter.FromDate.HasValue) q = q.Where(d => d.DonationDate >= filter.FromDate);
            if (filter.ToDate.HasValue) q = q.Where(d => d.DonationDate <= filter.ToDate);
            if (!string.IsNullOrEmpty(filter.Status)) q = q.Where(d => d.Status == filter.Status);
            if (!string.IsNullOrEmpty(filter.DonorName)) q = q.Where(d => d.Donor.FullName.Contains(filter.DonorName));
            ViewBag.Filter = filter;
            return View(await q.OrderByDescending(d => d.DonationDate).ToListAsync());
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Create()
        {
            ViewBag.Donors = new SelectList(await _db.Donors.OrderBy(d => d.FullName).ToListAsync(), "DonorId", "FullName");
            return View();
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Donation donation)
        {
            ModelState.Remove("Donor");
            if (!ModelState.IsValid)
            {
                ViewBag.Donors = new SelectList(await _db.Donors.OrderBy(d => d.FullName).ToListAsync(), "DonorId", "FullName");
                return View(donation);
            }
            donation.CreatedAt = DateTime.Now;
            _db.Donations.Add(donation);
            var donor = await _db.Donors.FindAsync(donation.DonorId);
            if (donor != null) donor.LastDonationDate = donation.DonationDate;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Donation recorded successfully!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Edit(int id)
        {
            var d = await _db.Donations.Include(d => d.Donor).FirstOrDefaultAsync(d => d.DonationId == id);
            if (d == null) return NotFound();
            ViewBag.Donors = new SelectList(await _db.Donors.OrderBy(d => d.FullName).ToListAsync(), "DonorId", "FullName", d.DonorId);
            return View(d);
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Donation donation)
        {
            if (id != donation.DonationId) return BadRequest();
            ModelState.Remove("Donor");
            if (!ModelState.IsValid)
            {
                ViewBag.Donors = new SelectList(await _db.Donors.OrderBy(d => d.FullName).ToListAsync(), "DonorId", "FullName");
                return View(donation);
            }
            _db.Update(donation);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Donation updated!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var donation = await _db.Donations.FindAsync(id);
            if (donation == null) return NotFound();
            donation.Status = "Approved";
            donation.ProcessedBy = User.Identity?.Name;
            var inventory = await _db.BloodInventories
                .Include(i => i.BloodType)
                .Join(_db.Donors.Where(d => d.DonorId == donation.DonorId), i => i.BloodTypeId, d => d.BloodTypeId, (i, d) => i)
                .FirstOrDefaultAsync();
            if (inventory != null) inventory.AvailableQuantityMl += donation.QuantityMl;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Donation approved and inventory updated!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(int id)
        {
            var donation = await _db.Donations.FindAsync(id);
            if (donation == null) return NotFound();
            donation.Status = "Rejected";
            donation.ProcessedBy = User.Identity?.Name;
            await _db.SaveChangesAsync();
            TempData["Info"] = "Donation rejected.";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var d = await _db.Donations.Include(d => d.Donor).FirstOrDefaultAsync(d => d.DonationId == id);
            if (d == null) return NotFound();
            return View(d);
        }

        [HttpPost, ActionName("Delete"), Authorize(Roles = "Admin"), ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var d = await _db.Donations.FindAsync(id);
            if (d != null) { _db.Donations.Remove(d); await _db.SaveChangesAsync(); }
            TempData["Success"] = "Donation deleted.";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> ExportExcel(DonationFilterViewModel filter)
        {
            var q = _db.Donations.Include(d => d.Donor).ThenInclude(d => d.BloodType).AsQueryable();
            if (filter.FromDate.HasValue) q = q.Where(d => d.DonationDate >= filter.FromDate);
            if (filter.ToDate.HasValue) q = q.Where(d => d.DonationDate <= filter.ToDate);
            if (!string.IsNullOrEmpty(filter.Status)) q = q.Where(d => d.Status == filter.Status);
            var donations = await q.OrderByDescending(d => d.DonationDate).ToListAsync();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Donations");
            ws.Cell(1, 1).Value = "Donor"; ws.Cell(1, 2).Value = "Blood Type"; ws.Cell(1, 3).Value = "Date";
            ws.Cell(1, 4).Value = "Quantity (ml)"; ws.Cell(1, 5).Value = "Status";
            ws.Row(1).Style.Font.Bold = true;
            int row = 2;
            foreach (var d in donations)
            {
                ws.Cell(row, 1).Value = d.Donor.FullName; ws.Cell(row, 2).Value = d.Donor.BloodType.Name;
                ws.Cell(row, 3).Value = d.DonationDate.ToString("yyyy-MM-dd");
                ws.Cell(row, 4).Value = (double)d.QuantityMl; ws.Cell(row, 5).Value = d.Status;
                row++;
            }
            ws.Columns().AdjustToContents();
            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return File(ms.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Donations.xlsx");
        }
    }
}
