using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BloodDonation.Models
{
    public class BloodType
    {
        public int BloodTypeId { get; set; }
        [Required, MaxLength(5)]
        public string Name { get; set; } = string.Empty; // A+, A-, B+, B-, AB+, AB-, O+, O-
        public ICollection<Donor> Donors { get; set; } = new List<Donor>();
        public ICollection<BloodRequest> BloodRequests { get; set; } = new List<BloodRequest>();
        public ICollection<BloodInventory> Inventories { get; set; } = new List<BloodInventory>();
    }

    public class Donor
    {
        public int DonorId { get; set; }
        [Required, MaxLength(100)]
        public string FullName { get; set; } = string.Empty;
        [Required]
        public string Email { get; set; } = string.Empty;
        [Required, MaxLength(20)]
        public string Phone { get; set; } = string.Empty;
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public string Gender { get; set; } = string.Empty;
        [Required]
        public string Address { get; set; } = string.Empty;
        public int BloodTypeId { get; set; }
        public BloodType BloodType { get; set; } = null!;
        public bool IsEligible { get; set; } = true;
        public DateTime? LastDonationDate { get; set; }
        public DateTime RegisteredAt { get; set; } = DateTime.Now;
        public ICollection<Donation> Donations { get; set; } = new List<Donation>();
    }

    public class Donation
    {
        public int DonationId { get; set; }
        public int DonorId { get; set; }
        public Donor Donor { get; set; } = null!;
        [Required]
        public DateTime DonationDate { get; set; }
        [Column(TypeName = "decimal(5,2)")]
        public decimal QuantityMl { get; set; } = 450;
        public string Status { get; set; } = "Pending"; // Pending, Approved, Rejected
        public string? Notes { get; set; }
        public string? ProcessedBy { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    public class Hospital
    {
        public int HospitalId { get; set; }
        [Required, MaxLength(150)]
        public string Name { get; set; } = string.Empty;
        [Required]
        public string Address { get; set; } = string.Empty;
        [Required, MaxLength(20)]
        public string Phone { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? ContactPerson { get; set; }
        public bool IsActive { get; set; } = true;
        public ICollection<BloodRequest> BloodRequests { get; set; } = new List<BloodRequest>();
    }

    public class BloodRequest
    {
        public int BloodRequestId { get; set; }
        public int HospitalId { get; set; }
        public Hospital Hospital { get; set; } = null!;
        public int BloodTypeId { get; set; }
        public BloodType BloodType { get; set; } = null!;
        [Column(TypeName = "decimal(6,2)")]
        public decimal QuantityMl { get; set; }
        public string Urgency { get; set; } = "Normal"; // Normal, Urgent, Critical
        public string Status { get; set; } = "Pending"; // Pending, Approved, Fulfilled, Rejected
        public string? PatientName { get; set; }
        public string? Notes { get; set; }
        public DateTime RequestDate { get; set; } = DateTime.Now;
        public DateTime? FulfilledDate { get; set; }
        public string? ProcessedBy { get; set; }
    }

    public class BloodInventory
    {
        public int InventoryId { get; set; }
        public int BloodTypeId { get; set; }
        public BloodType BloodType { get; set; } = null!;
        [Column(TypeName = "decimal(8,2)")]
        public decimal AvailableQuantityMl { get; set; }
        public DateTime LastUpdated { get; set; } = DateTime.Now;
        public DateTime? ExpiryDate { get; set; }
    }
}
