using BloodDonation.Data;
using BloodDonation.Models;
using BloodDonation.ViewModels;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize]
    public class BloodRequestsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public BloodRequestsController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index(BloodRequestFilterViewModel filter)
        {
            var q = _db.BloodRequests.Include(r => r.Hospital).Include(r => r.BloodType).AsQueryable();
            if (filter.FromDate.HasValue) q = q.Where(r => r.RequestDate >= filter.FromDate);
            if (filter.ToDate.HasValue) q = q.Where(r => r.RequestDate <= filter.ToDate);
            if (!string.IsNullOrEmpty(filter.Status)) q = q.Where(r => r.Status == filter.Status);
            if (!string.IsNullOrEmpty(filter.Urgency)) q = q.Where(r => r.Urgency == filter.Urgency);
            if (filter.HospitalId.HasValue) q = q.Where(r => r.HospitalId == filter.HospitalId);
            if (filter.BloodTypeId.HasValue) q = q.Where(r => r.BloodTypeId == filter.BloodTypeId);
            ViewBag.Hospitals = new SelectList(await _db.Hospitals.Where(h => h.IsActive).ToListAsync(), "HospitalId", "Name");
            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
            ViewBag.Filter = filter;
            return View(await q.OrderByDescending(r => r.RequestDate).ToListAsync());
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Create()
        {
            ViewBag.Hospitals = new SelectList(await _db.Hospitals.Where(h => h.IsActive).ToListAsync(), "HospitalId", "Name");
            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
            return View();
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BloodRequest req)
        {
            ModelState.Remove("Hospital"); ModelState.Remove("BloodType");
            if (!ModelState.IsValid)
            {
                ViewBag.Hospitals = new SelectList(await _db.Hospitals.Where(h => h.IsActive).ToListAsync(), "HospitalId", "Name");
                ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
                return View(req);
            }
            req.RequestDate = DateTime.Now;
            _db.BloodRequests.Add(req);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Blood request submitted!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Edit(int id)
        {
            var req = await _db.BloodRequests.FindAsync(id);
            if (req == null) return NotFound();
            ViewBag.Hospitals = new SelectList(await _db.Hospitals.Where(h => h.IsActive).ToListAsync(), "HospitalId", "Name", req.HospitalId);
            ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name", req.BloodTypeId);
            return View(req);
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, BloodRequest req)
        {
            if (id != req.BloodRequestId) return BadRequest();
            ModelState.Remove("Hospital"); ModelState.Remove("BloodType");
            if (!ModelState.IsValid)
            {
                ViewBag.Hospitals = new SelectList(await _db.Hospitals.Where(h => h.IsActive).ToListAsync(), "HospitalId", "Name");
                ViewBag.BloodTypes = new SelectList(await _db.BloodTypes.ToListAsync(), "BloodTypeId", "Name");
                return View(req);
            }
            _db.Update(req);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Request updated!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var req = await _db.BloodRequests.FindAsync(id);
            if (req == null) return NotFound();
            var inventory = await _db.BloodInventories.FirstOrDefaultAsync(i => i.BloodTypeId == req.BloodTypeId);
            if (inventory == null || inventory.AvailableQuantityMl < req.QuantityMl)
            {
                TempData["Error"] = "Insufficient blood inventory!";
                return RedirectToAction(nameof(Index));
            }
            req.Status = "Approved";
            req.ProcessedBy = User.Identity?.Name;
            inventory.AvailableQuantityMl -= req.QuantityMl;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Request approved and inventory updated!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(int id)
        {
            var req = await _db.BloodRequests.FindAsync(id);
            if (req == null) return NotFound();
            req.Status = "Rejected";
            req.ProcessedBy = User.Identity?.Name;
            await _db.SaveChangesAsync();
            TempData["Info"] = "Request rejected.";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var req = await _db.BloodRequests.Include(r => r.Hospital).Include(r => r.BloodType).FirstOrDefaultAsync(r => r.BloodRequestId == id);
            if (req == null) return NotFound();
            return View(req);
        }

        [HttpPost, ActionName("Delete"), Authorize(Roles = "Admin"), ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var req = await _db.BloodRequests.FindAsync(id);
            if (req != null) { _db.BloodRequests.Remove(req); await _db.SaveChangesAsync(); }
            TempData["Success"] = "Request deleted.";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> ExportExcel(BloodRequestFilterViewModel filter)
        {
            var requests = await _db.BloodRequests.Include(r => r.Hospital).Include(r => r.BloodType)
                .OrderByDescending(r => r.RequestDate).ToListAsync();
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("BloodRequests");
            ws.Cell(1, 1).Value = "Hospital"; ws.Cell(1, 2).Value = "Blood Type"; ws.Cell(1, 3).Value = "Quantity (ml)";
            ws.Cell(1, 4).Value = "Urgency"; ws.Cell(1, 5).Value = "Status"; ws.Cell(1, 6).Value = "Date";
            ws.Row(1).Style.Font.Bold = true;
            int row = 2;
            foreach (var r in requests)
            {
                ws.Cell(row, 1).Value = r.Hospital.Name; ws.Cell(row, 2).Value = r.BloodType.Name;
                ws.Cell(row, 3).Value = (double)r.QuantityMl; ws.Cell(row, 4).Value = r.Urgency;
                ws.Cell(row, 5).Value = r.Status; ws.Cell(row, 6).Value = r.RequestDate.ToString("yyyy-MM-dd");
                row++;
            }
            ws.Columns().AdjustToContents();
            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return File(ms.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "BloodRequests.xlsx");
        }
    }
}
