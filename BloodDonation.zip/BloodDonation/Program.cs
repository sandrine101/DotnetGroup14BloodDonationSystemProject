using BloodDonation.Data;
using BloodDonation.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")
        ?? "Data Source=BloodDonation.db"));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = false;
    options.Password.RequiredLength = 6;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.SignIn.RequireConfirmedAccount = false;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    string[] roles = { "Admin", "Manager", "Client" };
    foreach (var role in roles)
        if (!await roleManager.RoleExistsAsync(role))
            await roleManager.CreateAsync(new IdentityRole(role));
    if (await userManager.FindByEmailAsync("admin@blooddonation.com") == null)
    {
        var admin = new ApplicationUser { FullName = "System Admin", UserName = "admin@blooddonation.com", Email = "admin@blooddonation.com", Role = "Admin", EmailConfirmed = true };
        await userManager.CreateAsync(admin, "Admin123!");
        await userManager.AddToRoleAsync(admin, "Admin");
    }
    if (await userManager.FindByEmailAsync("manager@blooddonation.com") == null)
    {
        var mgr = new ApplicationUser { FullName = "Blood Manager", UserName = "manager@blooddonation.com", Email = "manager@blooddonation.com", Role = "Manager", EmailConfirmed = true };
        await userManager.CreateAsync(mgr, "Manager123!");
        await userManager.AddToRoleAsync(mgr, "Manager");
    }
    if (await userManager.FindByEmailAsync("client@blooddonation.com") == null)
    {
        var client = new ApplicationUser { FullName = "Test Client", UserName = "client@blooddonation.com", Email = "client@blooddonation.com", Role = "Client", EmailConfirmed = true };
        await userManager.CreateAsync(client, "Client123!");
        await userManager.AddToRoleAsync(client, "Client");
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();
