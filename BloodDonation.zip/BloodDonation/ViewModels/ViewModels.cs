using System.ComponentModel.DataAnnotations;

namespace BloodDonation.ViewModels
{
    public class LoginViewModel
    {
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
        [Required, DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;
        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        [Required, MaxLength(100)]
        public string FullName { get; set; } = string.Empty;
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
        [Required, DataType(DataType.Password), MinLength(6)]
        public string Password { get; set; } = string.Empty;
        [Compare("Password"), DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = string.Empty;
        public string Role { get; set; } = "Client";
    }

    public class DashboardViewModel
    {
        public int TotalDonors { get; set; }
        public int TotalDonations { get; set; }
        public int PendingDonations { get; set; }
        public int PendingRequests { get; set; }
        public int TotalHospitals { get; set; }
        public decimal TotalBloodAvailableMl { get; set; }
        public List<InventorySummary> InventorySummaries { get; set; } = new();
        public List<RecentDonation> RecentDonations { get; set; } = new();
        public List<UrgentRequest> UrgentRequests { get; set; } = new();
    }

    public class InventorySummary
    {
        public string BloodType { get; set; } = string.Empty;
        public decimal QuantityMl { get; set; }
        public string Level => QuantityMl switch { > 3000 => "High", > 1000 => "Medium", _ => "Low" };
    }

    public class RecentDonation
    {
        public string DonorName { get; set; } = string.Empty;
        public string BloodType { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string Status { get; set; } = string.Empty;
    }

    public class UrgentRequest
    {
        public string HospitalName { get; set; } = string.Empty;
        public string BloodType { get; set; } = string.Empty;
        public decimal QuantityMl { get; set; }
        public string Urgency { get; set; } = string.Empty;
    }

    public class DonorFilterViewModel
    {
        public string? SearchName { get; set; }
        public int? BloodTypeId { get; set; }
        public bool? IsEligible { get; set; }
        public string? Gender { get; set; }
    }

    public class DonationFilterViewModel
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string? Status { get; set; }
        public int? DonorId { get; set; }
        public string? DonorName { get; set; }
    }

    public class BloodRequestFilterViewModel
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string? Status { get; set; }
        public string? Urgency { get; set; }
        public int? HospitalId { get; set; }
        public int? BloodTypeId { get; set; }
    }
}
