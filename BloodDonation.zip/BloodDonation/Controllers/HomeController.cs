using BloodDonation.Data;
using BloodDonation.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodDonation.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;
        public HomeController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index()
        {
            var vm = new DashboardViewModel
            {
                TotalDonors = await _db.Donors.CountAsync(),
                TotalDonations = await _db.Donations.CountAsync(),
                PendingDonations = await _db.Donations.CountAsync(d => d.Status == "Pending"),
                PendingRequests = await _db.BloodRequests.CountAsync(r => r.Status == "Pending"),
                TotalHospitals = await _db.Hospitals.CountAsync(h => h.IsActive),
                TotalBloodAvailableMl = await _db.BloodInventories.SumAsync(i => i.AvailableQuantityMl),
                InventorySummaries = await _db.BloodInventories
                    .Include(i => i.BloodType)
                    .Select(i => new InventorySummary { BloodType = i.BloodType.Name, QuantityMl = i.AvailableQuantityMl })
                    .ToListAsync(),
                RecentDonations = await _db.Donations
                    .Include(d => d.Donor).ThenInclude(d => d.BloodType)
                    .OrderByDescending(d => d.DonationDate)
                    .Take(5)
                    .Select(d => new RecentDonation { DonorName = d.Donor.FullName, BloodType = d.Donor.BloodType.Name, Date = d.DonationDate, Status = d.Status })
                    .ToListAsync(),
                UrgentRequests = await _db.BloodRequests
                    .Include(r => r.Hospital).Include(r => r.BloodType)
                    .Where(r => r.Status == "Pending" && r.Urgency != "Normal")
                    .OrderByDescending(r => r.RequestDate)
                    .Take(5)
                    .Select(r => new UrgentRequest { HospitalName = r.Hospital.Name, BloodType = r.BloodType.Name, QuantityMl = r.QuantityMl, Urgency = r.Urgency })
                    .ToListAsync()
            };
            return View(vm);
        }

        [AllowAnonymous]
        public IActionResult Landing() => View();

        public IActionResult AccessDenied() => View();
    }
}
